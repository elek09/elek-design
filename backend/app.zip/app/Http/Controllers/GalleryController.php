<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\GalleryItem;

class GalleryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = GalleryItem::query()->where('active', true);
        if ($category = $request->query('category')) {
            $query->where('category', $category);
        }
        return $query->latest()->paginate(24)->through(fn($item) => [
            'id' => $item->id,
            'title' => $item->title,
            'category' => $item->category,
            'url' => asset('storage/' . $item->image_path),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'category' => ['nullable', 'string', 'max:60'],
            'description' => ['nullable', 'string'],
            'image' => ['required', 'image', 'max:5120'],
        ]);
        $imagePath = $request->file('image')->store('gallery', 'public');
        $galleryItem = GalleryItem::create([
            'title' => $request->title,
            'category' => $request->category,
            'description' => $request->description,
            'image_path' => $imagePath,
        ]);
        return response()->json([
            'id' => $galleryItem->id,
            'title' => $galleryItem->title,
            'url' => asset('storage/' . $galleryItem->image_path),
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
