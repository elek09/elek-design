<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\Product;
use App\Models\GalleryItem;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        // pár termék
        foreach ([
            ['name' => 'Próba Termék 1', 'price' => 1990],
            ['name' => 'Próba Termék 2', 'price' => 3490],
            ['name' => 'Próba Termék 3', 'price' => null],
        ] as $p) {
            Product::updateOrCreate(
                ['slug' => Str::slug($p['name'])],
                ['name' => $p['name'], 'description' => 'Demo leírás', 'price' => $p['price'], 'active' => true]
            );
        }

        // üres galéria bejegyzés (kép nélkül csak lista teszthez)
        GalleryItem::updateOrCreate(
            ['title' => 'Mintakép'],
            ['category' => 'demo', 'description' => 'Minta', 'image_path' => 'gallery/demo.jpg', 'active' => true]
        );
    }
}
